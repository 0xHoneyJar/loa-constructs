# Melange Protocol v0.8 — Architectural Overview

## Executive Summary

Melange is a **sender-side outbox communication protocol** for Constructs (human-AI pairs) built on GitHub Issues with Discord notifications. It enables cross-domain communication between AI-assisted teams while maintaining clear ownership, preventing backlog pollution, and ensuring reliable delivery.

---

## Core Concepts

### Construct
A **human-AI pair** working together on a specific domain.

```
┌─────────────────────────────────────┐
│            CONSTRUCT                │
│                                     │
│   ┌─────────┐      ┌─────────┐     │
│   │  Human  │ ←──→ │   AI    │     │
│   │ (soju)  │      │ (Claude)│     │
│   └─────────┘      └─────────┘     │
│                                     │
│   Domain: Taste, physics, feel      │
│   Name: Sigil                       │
└─────────────────────────────────────┘
```

### Sender-Side Outbox
Issues live in the **sender's repository**, not the receiver's. This prevents backlog pollution and keeps noise in the sender's yard until validated.

```
SENDER REPO (sigil)              RECEIVER
├── Code                              │
├── Docs                              │
└── OUTBOX (Melange Issues)           │
    └── Issue #10: to:loa  ──────────▶│ Receiver is notified
                                      │ Receiver comments to accept
                                      │ Receiver creates PR in own repo
```

### Artifact-Gated Commitment
Conversations are fluid (Issues). **Commitments require artifacts** (PRs with evidence).

```
Issue (conversation)     →     PR (commitment)
- Discussion                   - Code
- Clarification               - Deployment link
- Acceptance                  - Video evidence
```

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              MELANGE SYSTEM                                  │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────────┐     ┌──────────────────┐     ┌──────────────────┐
│   SIGIL REPO     │     │    LOA REPO      │     │  REGISTRY REPO   │
│                  │     │                  │     │                  │
│  Outbox:         │     │  Outbox:         │     │  Outbox:         │
│  - to:loa        │     │  - to:sigil      │     │  - to:sigil      │
│  - to:registry   │     │  - to:registry   │     │  - to:loa        │
│                  │     │                  │     │                  │
│  Issue Form ✓    │     │  Issue Form ✓    │     │  Issue Form ✓    │
│  Labels ✓        │     │  Labels ✓        │     │  Labels ✓        │
│  Notify Action ✓ │     │  Notify Action ✓ │     │  Notify Action ✓ │
└────────┬─────────┘     └────────┬─────────┘     └────────┬─────────┘
         │                        │                        │
         │    On Issue Create     │                        │
         │    with `melange`      │                        │
         │    label               │                        │
         ▼                        ▼                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         GITHUB ACTIONS                                       │
│                                                                              │
│   melange-notify.yml:                                                        │
│   - Triggered on Issue create/label                                          │
│   - Parses Issue for routing (to:*) and impact                              │
│   - Sends Discord webhook                                                    │
│                                                                              │
└────────────────────────────────────┬────────────────────────────────────────┘
                                     │
                                     ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           DISCORD                                            │
│                                                                              │
│   #melange channel:                                                          │
│                                                                              │
│   🔴 [game-changing] sigil → loa                                            │
│   Skill auto-triggering for support conversations                           │
│   https://github.com/0xHoneyJar/sigil/issues/10                             │
│   @here                                                                      │
│                                                                              │
│   🟡 [important] loa → sigil                                                │
│   Context preservation hints                                                 │
│   https://github.com/0xHoneyJar/loa/issues/5                                │
│                                                                              │
└────────────────────────────────────┬────────────────────────────────────────┘
                                     │
                                     │ Human clicks link
                                     ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                        RECEIVER WORKFLOW                                     │
│                                                                              │
│   1. Human receives Discord notification                                     │
│   2. Clicks link → opens Issue in sender's repo                             │
│   3. Comments "Accepted" → label: status:accepted                           │
│   4. Creates PR in own repo referencing sender's Issue                      │
│   5. Merges PR → comments "Resolved" → label: status:resolved               │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Component Details

### 1. GitHub App (Authentication)

```
┌─────────────────────────────────────────────────────────────────┐
│                      MELANGE APP                                 │
│                                                                  │
│   Identity: melange[bot]                                        │
│   Installed on: sigil, loa, registry repos                      │
│                                                                  │
│   Permissions:                                                   │
│   ├── Issues: Read & Write                                      │
│   ├── Pull Requests: Read & Write                               │
│   ├── Metadata: Read                                            │
│   └── Contents: Read                                            │
│                                                                  │
│   CANNOT:                                                        │
│   ├── Delete repos                                               │
│   ├── Push to protected branches                                │
│   ├── Access secrets                                            │
│   └── Modify settings                                           │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

Token Flow:
1. App generates JWT (signed with private key)
2. Requests installation token from GitHub
3. Token valid for 1 hour
4. Scoped to installed repos only
```

### 2. Issue Form (Schema)

```yaml
# .github/ISSUE_TEMPLATE/melange.yml

Fields:
├── To (Receiving Construct)    # Dropdown: sigil, loa, registry
├── From (Operator)             # Text: GitHub username
├── Intent                      # Dropdown: request, ask, report
├── Impact                      # Dropdown: game-changing, important, nice-to-have
├── Experience                  # Textarea: What's happening
├── Evidence                    # Textarea: Links, counts
├── Request                     # Textarea: What you need
└── Impact Reasoning            # Textarea: Why this impact level
```

**Rendered Output (parseable):**
```markdown
### To (Receiving Construct)

loa

### Impact

game-changing — Blocks core workflow

### Experience

Users report bugs...
```

### 3. Label Taxonomy

```
┌─────────────────────────────────────────────────────────────────┐
│                        LABELS                                    │
├─────────────────────────────────────────────────────────────────┤
│ TYPE                                                             │
│   melange (purple) — Marks Issue as Melange thread              │
├─────────────────────────────────────────────────────────────────┤
│ ROUTING                                                          │
│   to:sigil (blue)                                               │
│   to:loa (blue)                                                 │
│   to:registry (blue)                                            │
├─────────────────────────────────────────────────────────────────┤
│ IMPACT                                                           │
│   impact:game-changing (red) — Blocks core workflow             │
│   impact:important (yellow) — Significant friction              │
│   impact:nice-to-have (light blue) — Improvement                │
├─────────────────────────────────────────────────────────────────┤
│ STATUS                                                           │
│   status:open (green) — Awaiting response                       │
│   status:accepted (green) — Receiver working on it              │
│   status:blocked (yellow) — Waiting on external                 │
│   status:declined (gray) — Receiver declined                    │
│   status:resolved (gray) — Completed                            │
└─────────────────────────────────────────────────────────────────┘
```

### 4. Discord Notification Gateway

```
┌─────────────────────────────────────────────────────────────────┐
│                   NOTIFICATION RULES                             │
├─────────────────────────────────────────────────────────────────┤
│ IMPACT              │ NOTIFICATION                              │
├─────────────────────┼───────────────────────────────────────────┤
│ game-changing       │ 🔴 Immediate + @here ping                 │
│ important           │ 🟡 Notification, no ping                  │
│ nice-to-have        │ No notification (discoverable via search) │
└─────────────────────┴───────────────────────────────────────────┘

Message Format:
┌─────────────────────────────────────────────────────────────────┐
│ 🔴 **[game-changing] sigil → loa**                              │
│                                                                  │
│ [Melange] Skill auto-triggering for support conversations       │
│                                                                  │
│ https://github.com/0xHoneyJar/sigil/issues/10                   │
│                                                                  │
│ @here                                                            │
└─────────────────────────────────────────────────────────────────┘
```

### 5. Resilience Patterns

```
┌─────────────────────────────────────────────────────────────────┐
│                   EXPONENTIAL BACKOFF                            │
├─────────────────────────────────────────────────────────────────┤
│ Attempt 1: Immediate                                             │
│ Attempt 2: Wait 2s + jitter                                     │
│ Attempt 3: Wait 4s + jitter                                     │
│ Attempt 4: Wait 8s + jitter                                     │
│ Attempt 5: Wait 16s + jitter                                    │
│ Fail: Give up, alert human                                      │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                   CIRCUIT BREAKER                                │
├─────────────────────────────────────────────────────────────────┤
│ CLOSED ─────[5 failures]─────▶ OPEN                             │
│    ▲                             │                               │
│    │                             │ (30 min timeout)              │
│    │                             ▼                               │
│    └────[success]──────────── HALF-OPEN                         │
│                                  │                               │
│                         [failure]│                               │
│                                  ▼                               │
│                                OPEN + Discord Alert              │
└─────────────────────────────────────────────────────────────────┘
```

---

## Data Flow

### Creating a Melange Issue

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. SENDER CREATES ISSUE                                          │
└─────────────────────────────────────────────────────────────────┘
     │
     │  User fills out Issue Form in sender's repo
     │  (e.g., sigil repo)
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. GITHUB CREATES ISSUE                                          │
│                                                                  │
│    - Issue #10 created in sigil repo                            │
│    - Labels applied: melange, to:loa, impact:game-changing,     │
│      status:open                                                 │
└─────────────────────────────────────────────────────────────────┘
     │
     │  Issue create event triggers GitHub Action
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. GITHUB ACTION RUNS                                            │
│                                                                  │
│    - melange-notify.yml triggered                               │
│    - Parses labels: to:loa, impact:game-changing                │
│    - Constructs Discord message                                  │
│    - Sends to webhook                                            │
└─────────────────────────────────────────────────────────────────┘
     │
     │  HTTP POST to Discord webhook
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 4. DISCORD NOTIFICATION                                          │
│                                                                  │
│    #melange channel receives message                            │
│    @here notification sent (game-changing)                      │
└─────────────────────────────────────────────────────────────────┘
     │
     │  Human receives notification
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 5. RECEIVER RESPONDS                                             │
│                                                                  │
│    - Clicks link → opens Issue in sigil repo                    │
│    - Reads Issue                                                 │
│    - Comments: "Accepted"                                        │
│    - Updates label: status:open → status:accepted               │
└─────────────────────────────────────────────────────────────────┘
```

### Resolving a Melange Issue

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. RECEIVER CREATES PR                                           │
│                                                                  │
│    - PR created in receiver's repo (e.g., loa repo)             │
│    - Description: "Addresses 0xHoneyJar/sigil#10"               │
│    - Evidence: deployment link, video                            │
└─────────────────────────────────────────────────────────────────┘
     │
     │  PR reviewed and approved
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. PR MERGED                                                     │
└─────────────────────────────────────────────────────────────────┘
     │
     │  Receiver comments on original Issue
     │
     ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. ISSUE RESOLVED                                                │
│                                                                  │
│    - Comment: "Resolved via 0xHoneyJar/loa#49"                  │
│    - Label: status:accepted → status:resolved                   │
│    - Issue closed                                                │
└─────────────────────────────────────────────────────────────────┘
```

---

## Security Model

### Trust Boundaries

```
┌─────────────────────────────────────────────────────────────────┐
│                     TRUST BOUNDARY                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  TRUSTED (within App scope):                                    │
│  ├── Create/edit Issues                                         │
│  ├── Apply labels                                               │
│  ├── Post comments                                              │
│  ├── Create PRs                                                 │
│  └── Read repo metadata                                         │
│                                                                  │
│  UNTRUSTED (outside App scope):                                 │
│  ├── Delete repositories ✗                                      │
│  ├── Push to protected branches ✗                               │
│  ├── Access secrets ✗                                           │
│  ├── Modify repo settings ✗                                     │
│  └── Access other repos ✗                                       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Prompt Injection Mitigation

```
SCENARIO: Malicious prompt causes AI to execute harmful commands

WITH PAT (vulnerable):
└── Attacker has full user access
└── Can delete repos, push malware

WITH GITHUB APP (mitigated):
└── Attacker limited to App permissions
└── Can only create/edit Issues
└── Cannot cause permanent damage
```

### Validation

```
App-side validation (not label guards):
1. Check Issue has `melange` label
2. Check exactly one `to:*` label exists
3. Parse body to ensure form was used
4. Validate required fields present
5. Only then process the Issue
```

---

## File Structure

```
repository/
├── .github/
│   ├── ISSUE_TEMPLATE/
│   │   └── melange.yml              # Issue form template
│   ├── workflows/
│   │   └── melange-notify.yml       # Discord notification
│   └── melange.yml                  # Config (maintainers)
│
├── melange/                         # Python package
│   ├── __init__.py
│   ├── app.py                       # GitHub App auth
│   ├── parser.py                    # Issue parser
│   ├── issue.py                     # Issue CRUD
│   ├── inbox.py                     # Inbox queries
│   ├── resilience.py                # Backoff, circuit breaker
│   └── config.py                    # Configuration
│
└── scripts/
    └── create-labels.sh             # Label setup
```

---

## Evolution History

| Version | Key Change |
|---------|------------|
| 0.2 | Initial IPC with Mom Test protocol |
| 0.3 | Separated philosophy/schema/transport |
| 0.4 | Artifact-gated model |
| 0.5 | Email transport (killed in 0.6) |
| 0.6 | GitHub-native (Issues as protocol) |
| 0.7 | GitHub App, YAML forms, team assignment |
| **0.8** | **Sender-side outbox, Discord notifications, no hidden metadata** |

---

## Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Sender-side outbox | Prevents backlog pollution; sender owns their noise |
| No hidden metadata | Single source of truth; humans and AI read same data |
| Discord over GitHub notifications | Reliable delivery; dedicated channel; real-time |
| GitHub App over PAT | Scoped permissions; prompt injection mitigation |
| Link, don't transfer | Single Issue history; no split-brain |
| Exponential backoff + circuit breaker | Graceful degradation; human alerting |

---

## Success Criteria

| Metric | Target |
|--------|--------|
| Discord delivery rate | >99% |
| Parse failures | 0% |
| Backlog pollution complaints | 0 |
| Circuit breaker triggers | <1/month |
| Issue→resolution time (game-changing) | <7 days |
