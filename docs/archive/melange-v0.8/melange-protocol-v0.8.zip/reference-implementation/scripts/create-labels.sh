#!/bin/bash
#
# Melange Protocol - Label Setup Script
#
# Creates all required labels for a Melange-enabled repository.
#
# Usage:
#   ./create-labels.sh OWNER/REPO
#
# Example:
#   ./create-labels.sh 0xHoneyJar/sigil
#   ./create-labels.sh 0xHoneyJar/loa
#   ./create-labels.sh 0xHoneyJar/registry
#
# Requirements:
#   - GitHub CLI (gh) installed and authenticated
#

set -e

REPO=$1

if [ -z "$REPO" ]; then
  echo "Usage: ./create-labels.sh OWNER/REPO"
  echo ""
  echo "Example:"
  echo "  ./create-labels.sh 0xHoneyJar/sigil"
  exit 1
fi

echo "Creating Melange labels for $REPO..."
echo ""

# === Type ===
echo "Creating type labels..."
gh label create "melange" \
  --repo "$REPO" \
  --color "6f42c1" \
  --description "Melange protocol thread" \
  --force

# === Routing ===
echo "Creating routing labels..."
gh label create "to:sigil" \
  --repo "$REPO" \
  --color "1d76db" \
  --description "Addressed to Sigil" \
  --force

gh label create "to:loa" \
  --repo "$REPO" \
  --color "1d76db" \
  --description "Addressed to Loa" \
  --force

gh label create "to:registry" \
  --repo "$REPO" \
  --color "1d76db" \
  --description "Addressed to Registry" \
  --force

# === Impact ===
echo "Creating impact labels..."
gh label create "impact:game-changing" \
  --repo "$REPO" \
  --color "d73a4a" \
  --description "Blocks core workflow" \
  --force

gh label create "impact:important" \
  --repo "$REPO" \
  --color "fbca04" \
  --description "Significant friction" \
  --force

gh label create "impact:nice-to-have" \
  --repo "$REPO" \
  --color "c5def5" \
  --description "Improvement, not blocking" \
  --force

# === Status ===
echo "Creating status labels..."
gh label create "status:open" \
  --repo "$REPO" \
  --color "0e8a16" \
  --description "Awaiting receiver response" \
  --force

gh label create "status:accepted" \
  --repo "$REPO" \
  --color "0e8a16" \
  --description "Receiver accepted, working on it" \
  --force

gh label create "status:blocked" \
  --repo "$REPO" \
  --color "fbca04" \
  --description "Waiting on external input" \
  --force

gh label create "status:declined" \
  --repo "$REPO" \
  --color "6e7681" \
  --description "Receiver declined" \
  --force

gh label create "status:resolved" \
  --repo "$REPO" \
  --color "6e7681" \
  --description "Completed" \
  --force

# === Intent ===
echo "Creating intent labels..."
gh label create "intent:request" \
  --repo "$REPO" \
  --color "bfdadc" \
  --description "Requesting capability or change" \
  --force

gh label create "intent:ask" \
  --repo "$REPO" \
  --color "bfdadc" \
  --description "Requesting information" \
  --force

gh label create "intent:report" \
  --repo "$REPO" \
  --color "bfdadc" \
  --description "Reporting experience" \
  --force

echo ""
echo "✓ All Melange labels created for $REPO"
echo ""
echo "Next steps:"
echo "  1. Copy .github/ISSUE_TEMPLATE/melange.yml to your repo"
echo "  2. Copy .github/workflows/melange-notify.yml to your repo"
echo "  3. Add MELANGE_DISCORD_WEBHOOK secret to your repo"
echo "  4. Test by creating a Melange Issue"
