"""
Melange Protocol - Issue Parser

Parses GitHub Issues created via the Melange YAML form.
No hidden metadata - parses the visible rendered form directly.
"""

import re
from dataclasses import dataclass
from typing import Optional


@dataclass
class MelangeIssue:
    """Parsed Melange Issue data."""
    
    to_construct: str
    from_operator: str
    intent: str
    impact: str
    experience: str
    evidence: str
    request: str
    impact_reasoning: str
    
    # Metadata from GitHub
    number: Optional[int] = None
    url: Optional[str] = None
    repo: Optional[str] = None
    status: Optional[str] = None


def extract_field(body: str, field_name: str) -> str:
    """
    Extract a field value from the rendered Issue form.
    
    GitHub renders YAML forms as:
    ### Field Name
    
    <value>
    
    ### Next Field
    """
    # Escape special regex characters in field name
    escaped_name = re.escape(field_name)
    
    # Match: ### Field Name\n\n<content>\n\n### (or end)
    pattern = rf'###\s*{escaped_name}\s*\n\n(.*?)(?=\n\n###|\n\n---|\Z)'
    match = re.search(pattern, body, re.DOTALL | re.IGNORECASE)
    
    if match:
        return match.group(1).strip()
    return ""


def extract_value_before_delimiter(value: str, delimiter: str = " — ") -> str:
    """
    Extract value before delimiter.
    
    Example: "game-changing — Blocks core workflow" → "game-changing"
    """
    if delimiter in value:
        return value.split(delimiter)[0].strip()
    return value.strip()


def parse_melange_issue(body: str) -> MelangeIssue:
    """
    Parse a Melange Issue from its rendered body.
    
    Args:
        body: The Issue body as rendered by GitHub
        
    Returns:
        MelangeIssue with extracted fields
        
    Raises:
        ValueError: If required fields are missing
    """
    # Extract all fields
    to_construct = extract_field(body, "To (Receiving Construct)")
    from_operator = extract_field(body, "From (Your GitHub username)")
    intent_raw = extract_field(body, "Intent")
    impact_raw = extract_field(body, "Impact")
    experience = extract_field(body, "Experience")
    evidence = extract_field(body, "Evidence")
    request = extract_field(body, "Request")
    impact_reasoning = extract_field(body, "Impact Reasoning")
    
    # Clean up dropdown values (remove description after delimiter)
    intent = extract_value_before_delimiter(intent_raw)
    impact = extract_value_before_delimiter(impact_raw)
    
    # Validate required fields
    if not to_construct:
        raise ValueError("Missing required field: To (Receiving Construct)")
    if not impact:
        raise ValueError("Missing required field: Impact")
    if not experience:
        raise ValueError("Missing required field: Experience")
    
    return MelangeIssue(
        to_construct=to_construct.lower(),
        from_operator=from_operator,
        intent=intent.lower() if intent else "request",
        impact=impact.lower(),
        experience=experience,
        evidence=evidence,
        request=request,
        impact_reasoning=impact_reasoning
    )


def parse_issue_from_api(issue_data: dict) -> MelangeIssue:
    """
    Parse a Melange Issue from GitHub API response.
    
    Args:
        issue_data: Issue object from GitHub API
        
    Returns:
        MelangeIssue with all fields populated
    """
    parsed = parse_melange_issue(issue_data["body"])
    
    # Add metadata
    parsed.number = issue_data["number"]
    parsed.url = issue_data["html_url"]
    parsed.repo = issue_data["repository"]["full_name"] if "repository" in issue_data else None
    
    # Extract status from labels
    labels = [l["name"] for l in issue_data.get("labels", [])]
    status_labels = [l for l in labels if l.startswith("status:")]
    parsed.status = status_labels[0].replace("status:", "") if status_labels else "unknown"
    
    return parsed


def get_label_value(labels: list[dict], prefix: str) -> Optional[str]:
    """
    Extract value from a prefixed label.
    
    Example: labels=[{name: "to:loa"}], prefix="to:" → "loa"
    """
    for label in labels:
        name = label["name"]
        if name.startswith(prefix):
            return name[len(prefix):]
    return None
