"""
Melange Protocol - GitHub App Authentication

Handles JWT generation and installation token management for the Melange GitHub App.
Tokens are cached and auto-refreshed.
"""

import os
import time
import jwt
import requests
from dataclasses import dataclass
from typing import Optional


@dataclass
class MelangeApp:
    """GitHub App client for Melange Protocol."""
    
    app_id: str
    installation_id: str
    private_key: str
    
    _token: Optional[str] = None
    _token_expires: float = 0
    
    @classmethod
    def from_env(cls) -> "MelangeApp":
        """Create MelangeApp from environment variables."""
        return cls(
            app_id=os.environ["MELANGE_APP_ID"],
            installation_id=os.environ["MELANGE_INSTALLATION_ID"],
            private_key=os.environ["MELANGE_PRIVATE_KEY"]
        )
    
    def _generate_jwt(self) -> str:
        """Generate JWT for GitHub App authentication."""
        now = int(time.time())
        payload = {
            "iat": now - 60,        # Issued 60s ago (clock skew tolerance)
            "exp": now + 600,       # Expires in 10 minutes
            "iss": self.app_id
        }
        return jwt.encode(payload, self.private_key, algorithm="RS256")
    
    def get_token(self) -> str:
        """
        Get installation access token.
        
        Tokens are cached and auto-refreshed when <5 minutes remain.
        """
        # Return cached token if still valid (with 5 min buffer)
        if self._token and time.time() < self._token_expires - 300:
            return self._token
        
        # Request new token
        jwt_token = self._generate_jwt()
        response = requests.post(
            f"https://api.github.com/app/installations/{self.installation_id}/access_tokens",
            headers={
                "Authorization": f"Bearer {jwt_token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28"
            }
        )
        response.raise_for_status()
        data = response.json()
        
        self._token = data["token"]
        # Tokens are typically valid for 1 hour
        self._token_expires = time.time() + 3600
        
        return self._token
    
    def request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        """
        Make authenticated request to GitHub API.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint (e.g., /repos/owner/repo/issues)
            **kwargs: Additional arguments passed to requests
        
        Returns:
            Response object
        """
        token = self.get_token()
        headers = kwargs.pop("headers", {})
        headers.update({
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28"
        })
        
        url = f"https://api.github.com{endpoint}"
        response = requests.request(method, url, headers=headers, **kwargs)
        return response
    
    def get(self, endpoint: str, **kwargs) -> requests.Response:
        """GET request to GitHub API."""
        return self.request("GET", endpoint, **kwargs)
    
    def post(self, endpoint: str, **kwargs) -> requests.Response:
        """POST request to GitHub API."""
        return self.request("POST", endpoint, **kwargs)
    
    def patch(self, endpoint: str, **kwargs) -> requests.Response:
        """PATCH request to GitHub API."""
        return self.request("PATCH", endpoint, **kwargs)
