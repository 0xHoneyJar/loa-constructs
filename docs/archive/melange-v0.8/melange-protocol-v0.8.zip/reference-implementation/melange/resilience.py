"""
Melange Protocol - Resilience Patterns

Exponential backoff and circuit breaker for API reliability.
"""

import os
import time
import random
import requests
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from functools import wraps
from typing import Callable, TypeVar, Any

T = TypeVar("T")


# =============================================================================
# Exponential Backoff
# =============================================================================

def with_retry(
    fn: Callable[[], T] = None,
    max_retries: int = 5,
    base_delay: float = 1.0,
    max_delay: float = 60.0
) -> T:
    """
    Execute function with exponential backoff on failure.
    
    Can be used as decorator or wrapper:
    
        @with_retry
        def my_function():
            ...
            
        # or
        
        result = with_retry(lambda: api_call())
    
    Args:
        fn: Function to execute
        max_retries: Maximum retry attempts
        base_delay: Initial delay in seconds
        max_delay: Maximum delay in seconds
        
    Returns:
        Function result
        
    Raises:
        Last exception if all retries fail
    """
    def decorator(func: Callable[[], T]) -> Callable[[], T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except requests.exceptions.RequestException as e:
                    last_exception = e
                    
                    if attempt == max_retries - 1:
                        raise
                    
                    # Calculate delay with exponential backoff + jitter
                    delay = min(base_delay * (2 ** attempt), max_delay)
                    jitter = random.uniform(0, delay * 0.1)
                    total_delay = delay + jitter
                    
                    print(f"Attempt {attempt + 1} failed: {e}. Retrying in {total_delay:.1f}s")
                    time.sleep(total_delay)
            
            raise last_exception
        
        return wrapper
    
    # Allow use as @with_retry or with_retry(fn)
    if fn is not None:
        return decorator(fn)()
    return decorator


# =============================================================================
# Circuit Breaker
# =============================================================================

@dataclass
class CircuitBreaker:
    """
    Circuit breaker for API calls.
    
    States:
    - CLOSED: Normal operation, requests pass through
    - OPEN: Failures exceeded threshold, requests blocked
    - HALF_OPEN: Testing if service recovered
    
    Usage:
        breaker = CircuitBreaker()
        
        if breaker.can_proceed():
            try:
                result = api_call()
                breaker.record_success()
            except Exception:
                breaker.record_failure()
    """
    
    failure_threshold: int = 5
    reset_timeout: timedelta = field(default_factory=lambda: timedelta(minutes=30))
    
    _failures: int = field(default=0, init=False)
    _last_failure: datetime = field(default=None, init=False)
    _state: str = field(default="closed", init=False)  # closed, open, half_open
    _alert_sent: bool = field(default=False, init=False)
    
    def can_proceed(self) -> bool:
        """Check if request should proceed."""
        if self._state == "closed":
            return True
        
        if self._state == "open":
            # Check if timeout has passed
            if self._last_failure and datetime.now() - self._last_failure > self.reset_timeout:
                self._state = "half_open"
                return True
            return False
        
        # half_open: allow one test request
        return True
    
    def record_success(self) -> None:
        """Record successful request."""
        self._failures = 0
        self._state = "closed"
        self._alert_sent = False
    
    def record_failure(self) -> None:
        """Record failed request."""
        self._failures += 1
        self._last_failure = datetime.now()
        
        if self._failures >= self.failure_threshold:
            self._state = "open"
            if not self._alert_sent:
                self._send_alert()
                self._alert_sent = True
    
    def _send_alert(self) -> None:
        """Send alert when circuit opens."""
        webhook_url = os.environ.get("MELANGE_ALERTS_WEBHOOK")
        if not webhook_url:
            print("WARNING: Circuit breaker opened but no alert webhook configured")
            return
        
        message = (
            "⚠️ **Melange Circuit Breaker OPEN**\n\n"
            f"GitHub API failures exceeded threshold ({self.failure_threshold}).\n"
            f"Circuit will attempt recovery in {self.reset_timeout}.\n"
            "Manual intervention may be required."
        )
        
        try:
            requests.post(webhook_url, json={"content": message}, timeout=10)
        except Exception as e:
            print(f"Failed to send circuit breaker alert: {e}")
    
    @property
    def state(self) -> str:
        """Current circuit state."""
        return self._state
    
    @property
    def failure_count(self) -> int:
        """Current failure count."""
        return self._failures


# Global circuit breaker instance
_circuit_breaker = CircuitBreaker()


def get_circuit_breaker() -> CircuitBreaker:
    """Get the global circuit breaker instance."""
    return _circuit_breaker


def with_circuit_breaker(fn: Callable[[], T]) -> T:
    """
    Execute function with circuit breaker protection.
    
    Args:
        fn: Function to execute
        
    Returns:
        Function result
        
    Raises:
        Exception if circuit is open or function fails
    """
    breaker = get_circuit_breaker()
    
    if not breaker.can_proceed():
        raise Exception(
            f"Circuit breaker is {breaker.state}. "
            f"Failures: {breaker.failure_count}. "
            "Manual intervention required."
        )
    
    try:
        result = fn()
        breaker.record_success()
        return result
    except Exception:
        breaker.record_failure()
        raise


# =============================================================================
# Discord Alerts
# =============================================================================

def send_discord_alert(message: str, webhook_url: str = None) -> bool:
    """
    Send alert to Discord.
    
    Args:
        message: Alert message
        webhook_url: Discord webhook URL (or uses MELANGE_ALERTS_WEBHOOK env var)
        
    Returns:
        True if sent successfully
    """
    url = webhook_url or os.environ.get("MELANGE_ALERTS_WEBHOOK")
    if not url:
        print(f"ALERT (no webhook): {message}")
        return False
    
    try:
        response = requests.post(url, json={"content": message}, timeout=10)
        return response.status_code == 204
    except Exception as e:
        print(f"Failed to send Discord alert: {e}")
        return False


def send_melange_notification(
    title: str,
    from_construct: str,
    to_construct: str,
    impact: str,
    url: str,
    webhook_url: str = None
) -> bool:
    """
    Send Melange Issue notification to Discord.
    
    Args:
        title: Issue title
        from_construct: Sender construct
        to_construct: Receiver construct
        impact: Impact level
        url: Issue URL
        webhook_url: Discord webhook URL
        
    Returns:
        True if sent successfully
    """
    webhook = webhook_url or os.environ.get("MELANGE_DISCORD_WEBHOOK")
    if not webhook:
        return False
    
    # Format based on impact
    if impact == "game-changing":
        emoji = "🔴"
        ping = "\n\n@here"
    elif impact == "important":
        emoji = "🟡"
        ping = ""
    else:
        # nice-to-have: no notification
        return True
    
    message = f"{emoji} **[{impact}] {from_construct} → {to_construct}**\n\n{title}\n\n{url}{ping}"
    
    try:
        response = requests.post(webhook, json={"content": message}, timeout=10)
        return response.status_code == 204
    except Exception as e:
        print(f"Failed to send Melange notification: {e}")
        return False
