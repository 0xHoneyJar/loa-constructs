"""
Melange Protocol v0.8

Sender-side outbox communication for Constructs using GitHub Issues.
"""

from .app import MelangeApp
from .parser import MelangeIssue, parse_melange_issue
from .issue import (
    IssueCreateRequest,
    create_issue,
    update_status,
    add_comment,
    close_issue,
    accept_issue,
    decline_issue
)
from .inbox import (
    inbox,
    get_issue,
    get_thread,
    validate_melange_issue
)
from .resilience import (
    with_retry,
    CircuitBreaker,
    get_circuit_breaker,
    with_circuit_breaker,
    send_discord_alert,
    send_melange_notification
)

__version__ = "0.8.0"

__all__ = [
    # App
    "MelangeApp",
    
    # Parser
    "MelangeIssue",
    "parse_melange_issue",
    
    # Issue management
    "IssueCreateRequest",
    "create_issue",
    "update_status", 
    "add_comment",
    "close_issue",
    "accept_issue",
    "decline_issue",
    
    # Inbox
    "inbox",
    "get_issue",
    "get_thread",
    "validate_melange_issue",
    
    # Resilience
    "with_retry",
    "CircuitBreaker",
    "get_circuit_breaker",
    "with_circuit_breaker",
    "send_discord_alert",
    "send_melange_notification"
]
