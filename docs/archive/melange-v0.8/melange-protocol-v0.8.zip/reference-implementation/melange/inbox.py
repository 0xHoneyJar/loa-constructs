"""
Melange Protocol - Inbox Queries

Query for Melange Issues addressed to a Construct across all org repos.
"""

from typing import Optional
from .app import MelangeApp
from .parser import MelangeIssue, parse_issue_from_api, get_label_value
from .resilience import with_retry


def inbox(
    app: MelangeApp,
    construct: str,
    org: str = "0xHoneyJar",
    status: Optional[str] = None,
    impact: Optional[str] = None
) -> list[dict]:
    """
    Get all open Melange Issues addressed to a Construct.
    
    Args:
        app: Authenticated MelangeApp
        construct: Target construct (e.g., "loa")
        org: GitHub organization
        status: Optional status filter (open, accepted, blocked)
        impact: Optional impact filter (game-changing, important, nice-to-have)
        
    Returns:
        List of Issue summaries sorted by impact (game-changing first)
    """
    # Build search query
    query_parts = [
        f"org:{org}",
        "is:issue",
        "is:open",
        "label:melange",
        f"label:to:{construct}"
    ]
    
    if status:
        query_parts.append(f"label:status:{status}")
    
    if impact:
        query_parts.append(f"label:impact:{impact}")
    
    query = " ".join(query_parts)
    
    @with_retry
    def _search():
        response = app.get(
            "/search/issues",
            params={"q": query, "sort": "created", "order": "desc", "per_page": 100}
        )
        response.raise_for_status()
        return response.json()
    
    results = _search()
    
    # Parse and sort by impact
    issues = []
    for item in results.get("items", []):
        labels = item.get("labels", [])
        
        # Extract key info from labels
        impact_value = get_label_value(labels, "impact:")
        status_value = get_label_value(labels, "status:")
        from_value = get_label_value(labels, "to:")  # Actually this is wrong, need from
        
        # Determine sender from repo (sender creates in their own repo)
        repo_name = item["repository_url"].split("/")[-1] if "repository_url" in item else "unknown"
        
        issues.append({
            "number": item["number"],
            "title": item["title"],
            "url": item["html_url"],
            "repo": f"{org}/{repo_name}",
            "impact": impact_value or "unknown",
            "status": status_value or "open",
            "from_repo": repo_name,
            "created_at": item["created_at"],
            "updated_at": item["updated_at"]
        })
    
    # Sort by impact priority
    impact_order = {"game-changing": 0, "important": 1, "nice-to-have": 2, "unknown": 3}
    issues.sort(key=lambda x: impact_order.get(x["impact"], 3))
    
    return issues


def get_issue(app: MelangeApp, repo: str, issue_number: int) -> MelangeIssue:
    """
    Get and parse a specific Melange Issue.
    
    Args:
        app: Authenticated MelangeApp
        repo: Repository (e.g., "0xHoneyJar/sigil")
        issue_number: Issue number
        
    Returns:
        Parsed MelangeIssue
    """
    owner, repo_name = repo.split("/")
    
    @with_retry
    def _get():
        response = app.get(f"/repos/{owner}/{repo_name}/issues/{issue_number}")
        response.raise_for_status()
        return response.json()
    
    issue_data = _get()
    issue_data["repository"] = {"full_name": repo}
    
    return parse_issue_from_api(issue_data)


def get_thread(app: MelangeApp, repo: str, issue_number: int) -> dict:
    """
    Get a Melange Issue with all its comments (full thread).
    
    Args:
        app: Authenticated MelangeApp
        repo: Repository
        issue_number: Issue number
        
    Returns:
        Dict with Issue and comments
    """
    owner, repo_name = repo.split("/")
    
    # Get Issue
    issue = get_issue(app, repo, issue_number)
    
    # Get comments
    @with_retry
    def _get_comments():
        response = app.get(
            f"/repos/{owner}/{repo_name}/issues/{issue_number}/comments",
            params={"per_page": 100}
        )
        response.raise_for_status()
        return response.json()
    
    comments = _get_comments()
    
    return {
        "issue": issue,
        "comments": [
            {
                "author": c["user"]["login"],
                "body": c["body"],
                "created_at": c["created_at"]
            }
            for c in comments
        ]
    }


def validate_melange_issue(issue_data: dict) -> bool:
    """
    Validate that an Issue is a legitimate Melange Issue.
    
    Checks:
    - Has `melange` label
    - Has exactly one `to:*` label
    - Has exactly one `impact:*` label
    - Body can be parsed
    
    Args:
        issue_data: Issue object from GitHub API
        
    Returns:
        True if valid, False otherwise
    """
    labels = [l["name"] for l in issue_data.get("labels", [])]
    
    # Must have melange label
    if "melange" not in labels:
        return False
    
    # Must have exactly one to:* label
    to_labels = [l for l in labels if l.startswith("to:")]
    if len(to_labels) != 1:
        return False
    
    # Must have exactly one impact:* label
    impact_labels = [l for l in labels if l.startswith("impact:")]
    if len(impact_labels) != 1:
        return False
    
    # Must be parseable
    try:
        from .parser import parse_melange_issue
        parse_melange_issue(issue_data.get("body", ""))
    except (ValueError, Exception):
        return False
    
    return True
