"""
Melange Protocol - Issue Management

Create and manage Melange Issues in sender's repo (outbox model).
"""

from dataclasses import dataclass
from typing import Optional
from .app import MelangeApp
from .parser import MelangeIssue, parse_issue_from_api
from .resilience import with_retry


@dataclass
class IssueCreateRequest:
    """Request to create a Melange Issue."""
    
    repo: str               # Sender's repo (e.g., "0xHoneyJar/sigil")
    to_construct: str       # Receiving construct (e.g., "loa")
    from_operator: str      # Sender's GitHub username
    intent: str             # request, ask, or report
    impact: str             # game-changing, important, nice-to-have
    experience: str         # What's happening
    evidence: str           # Supporting evidence
    request: str            # What you need
    impact_reasoning: str   # Why this impact level
    title: Optional[str] = None  # Optional custom title


def create_issue(app: MelangeApp, req: IssueCreateRequest) -> dict:
    """
    Create a Melange Issue in the sender's repo.
    
    Args:
        app: Authenticated MelangeApp
        req: Issue creation request
        
    Returns:
        Created Issue data from GitHub API
    """
    # Generate title if not provided
    title = req.title or f"[Melange] {req.request[:60]}..."
    if not title.startswith("[Melange]"):
        title = f"[Melange] {title}"
    
    # Format body to match YAML form output
    body = f"""### To (Receiving Construct)

{req.to_construct}

### From (Your GitHub username)

{req.from_operator}

### Intent

{req.intent} — {"Need capability or change" if req.intent == "request" else "Need information" if req.intent == "ask" else "Sharing experience"}

### Impact

{req.impact} — {"Blocks core workflow" if req.impact == "game-changing" else "Significant friction" if req.impact == "important" else "Improvement"}

### Experience

{req.experience}

### Evidence

{req.evidence}

### Request

{req.request}

### Impact Reasoning

{req.impact_reasoning}
"""
    
    # Build labels
    labels = [
        "melange",
        f"to:{req.to_construct}",
        f"impact:{req.impact}",
        f"intent:{req.intent}",
        "status:open"
    ]
    
    # Create Issue via API
    owner, repo = req.repo.split("/")
    
    @with_retry
    def _create():
        response = app.post(
            f"/repos/{owner}/{repo}/issues",
            json={
                "title": title,
                "body": body,
                "labels": labels
            }
        )
        response.raise_for_status()
        return response.json()
    
    return _create()


def update_status(app: MelangeApp, repo: str, issue_number: int, status: str) -> dict:
    """
    Update the status label on a Melange Issue.
    
    Args:
        app: Authenticated MelangeApp
        repo: Repository (e.g., "0xHoneyJar/sigil")
        issue_number: Issue number
        status: New status (open, accepted, blocked, declined, resolved)
        
    Returns:
        Updated Issue data
    """
    owner, repo_name = repo.split("/")
    
    # Get current labels
    response = app.get(f"/repos/{owner}/{repo_name}/issues/{issue_number}")
    response.raise_for_status()
    issue = response.json()
    
    # Remove old status labels, add new one
    current_labels = [l["name"] for l in issue["labels"]]
    new_labels = [l for l in current_labels if not l.startswith("status:")]
    new_labels.append(f"status:{status}")
    
    # Update labels
    @with_retry
    def _update():
        response = app.patch(
            f"/repos/{owner}/{repo_name}/issues/{issue_number}",
            json={"labels": new_labels}
        )
        response.raise_for_status()
        return response.json()
    
    return _update()


def add_comment(app: MelangeApp, repo: str, issue_number: int, body: str) -> dict:
    """
    Add a comment to a Melange Issue.
    
    Args:
        app: Authenticated MelangeApp
        repo: Repository (e.g., "0xHoneyJar/sigil")
        issue_number: Issue number
        body: Comment body
        
    Returns:
        Created comment data
    """
    owner, repo_name = repo.split("/")
    
    @with_retry
    def _comment():
        response = app.post(
            f"/repos/{owner}/{repo_name}/issues/{issue_number}/comments",
            json={"body": body}
        )
        response.raise_for_status()
        return response.json()
    
    return _comment()


def close_issue(
    app: MelangeApp,
    repo: str,
    issue_number: int,
    comment: Optional[str] = None
) -> dict:
    """
    Close a Melange Issue with optional resolution comment.
    
    Args:
        app: Authenticated MelangeApp
        repo: Repository
        issue_number: Issue number
        comment: Optional closing comment
        
    Returns:
        Updated Issue data
    """
    owner, repo_name = repo.split("/")
    
    # Add comment if provided
    if comment:
        add_comment(app, repo, issue_number, comment)
    
    # Update status label
    update_status(app, repo, issue_number, "resolved")
    
    # Close issue
    @with_retry
    def _close():
        response = app.patch(
            f"/repos/{owner}/{repo_name}/issues/{issue_number}",
            json={"state": "closed"}
        )
        response.raise_for_status()
        return response.json()
    
    return _close()


def accept_issue(app: MelangeApp, repo: str, issue_number: int, message: str = "Accepted.") -> dict:
    """
    Accept a Melange Issue (receiver acknowledges and will work on it).
    
    Args:
        app: Authenticated MelangeApp
        repo: Repository containing the Issue
        issue_number: Issue number
        message: Acceptance message
        
    Returns:
        Updated Issue data
    """
    add_comment(app, repo, issue_number, f"**{message}**")
    return update_status(app, repo, issue_number, "accepted")


def decline_issue(app: MelangeApp, repo: str, issue_number: int, reason: str) -> dict:
    """
    Decline a Melange Issue with reason.
    
    Args:
        app: Authenticated MelangeApp
        repo: Repository containing the Issue
        issue_number: Issue number
        reason: Reason for declining
        
    Returns:
        Updated Issue data
    """
    comment = f"""**Declined.**

{reason}
"""
    return close_issue(app, repo, issue_number, comment)
