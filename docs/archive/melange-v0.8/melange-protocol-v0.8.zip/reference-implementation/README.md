# Melange Protocol v0.8 — Reference Implementation

Sender-side outbox communication for Constructs using GitHub Issues with Discord notifications.

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Create GitHub App

1. Go to GitHub → Settings → Developer Settings → GitHub Apps
2. Create new App named "Melange"
3. Set permissions:
   - Issues: Read & Write
   - Pull Requests: Read & Write
   - Metadata: Read
   - Contents: Read
4. Install on your repos (sigil, loa, registry)
5. Note the App ID and Installation ID
6. Generate and download private key

### 3. Set Environment Variables

```bash
export MELANGE_APP_ID="123456"
export MELANGE_INSTALLATION_ID="12345678"
export MELANGE_PRIVATE_KEY="$(cat /path/to/private-key.pem)"
export MELANGE_DISCORD_WEBHOOK="https://discord.com/api/webhooks/..."
export MELANGE_ALERTS_WEBHOOK="https://discord.com/api/webhooks/..."  # Optional
export GITHUB_ORG="0xHoneyJar"
```

### 4. Setup Labels

```bash
chmod +x scripts/create-labels.sh
./scripts/create-labels.sh 0xHoneyJar/sigil
./scripts/create-labels.sh 0xHoneyJar/loa
./scripts/create-labels.sh 0xHoneyJar/registry
```

### 5. Copy GitHub Files

Copy to each repo:
- `.github/ISSUE_TEMPLATE/melange.yml`
- `.github/workflows/melange-notify.yml`

Add secret `MELANGE_DISCORD_WEBHOOK` to each repo.

## Usage

### Create a Melange Issue (Programmatic)

```python
from melange import MelangeApp, IssueCreateRequest, create_issue

# Initialize
app = MelangeApp.from_env()

# Create Issue in sender's repo
req = IssueCreateRequest(
    repo="0xHoneyJar/sigil",      # Your repo (sender)
    to_construct="loa",            # Receiver
    from_operator="soju",
    intent="request",
    impact="game-changing",
    experience="Users report bugs, I jump to code instead of asking about experience.",
    evidence="- Issue: #50\n- Observations: 3 incidents",
    request="Can RLM core detect support conversations?",
    impact_reasoning="Without this, every support conversation starts wrong."
)

issue = create_issue(app, req)
print(f"Created: {issue['html_url']}")
```

### Create a Melange Issue (Web UI)

1. Go to your repo → Issues → New Issue
2. Select "Melange Thread" template
3. Fill out the form
4. Submit

The GitHub Action will:
- Apply routing labels (to:*, impact:*)
- Send Discord notification (if game-changing or important)

### Check Inbox

```python
from melange import MelangeApp, inbox

app = MelangeApp.from_env()

# Get all Issues addressed to Loa
issues = inbox(app, construct="loa")

for issue in issues:
    print(f"[{issue['impact']}] {issue['title']} ({issue['repo']}#{issue['number']})")
```

### Accept an Issue

```python
from melange import MelangeApp, accept_issue

app = MelangeApp.from_env()

# Accept Issue (adds comment + updates status label)
accept_issue(app, "0xHoneyJar/sigil", 10, "Accepted. Building this in Loa.")
```

### Resolve an Issue

```python
from melange import MelangeApp, close_issue

app = MelangeApp.from_env()

# Close with resolution comment
close_issue(
    app,
    "0xHoneyJar/sigil",
    10,
    "Resolved via 0xHoneyJar/loa#49"
)
```

## File Structure

```
melange/
├── __init__.py          # Package exports
├── app.py               # GitHub App authentication
├── parser.py            # Issue body parser
├── issue.py             # Issue CRUD operations
├── inbox.py             # Inbox queries
└── resilience.py        # Backoff, circuit breaker

.github/
├── ISSUE_TEMPLATE/
│   └── melange.yml      # Issue form template
└── workflows/
    └── melange-notify.yml   # Discord notification

scripts/
└── create-labels.sh     # Label setup
```

## Label Taxonomy

| Category | Labels |
|----------|--------|
| Type | `melange` |
| Routing | `to:sigil`, `to:loa`, `to:registry` |
| Impact | `impact:game-changing`, `impact:important`, `impact:nice-to-have` |
| Status | `status:open`, `status:accepted`, `status:blocked`, `status:declined`, `status:resolved` |
| Intent | `intent:request`, `intent:ask`, `intent:report` |

## Discord Notifications

| Impact | Notification |
|--------|--------------|
| game-changing | 🔴 Immediate + @here |
| important | 🟡 Notification |
| nice-to-have | None (discoverable via search) |

## Architecture

See `ARCHITECTURE.md` for full system design.

Key principles:
1. **Sender-side outbox** — Issues live in sender's repo
2. **No hidden metadata** — Parse visible form output
3. **Discord for critical** — Real-time notifications
4. **GitHub App** — Scoped permissions, no PATs
5. **Link, don't transfer** — Single Issue history

## License

MIT
