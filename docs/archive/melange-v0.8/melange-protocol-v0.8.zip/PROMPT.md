# Melange Protocol Implementation Prompt

You are implementing the Melange Protocol v0.8 — a sender-side outbox communication system for Constructs (human-AI pairs) using GitHub Issues and Discord notifications.

## Context

Melange enables cross-Construct communication where:
- **Constructs** are human-AI pairs (e.g., Sigil = soju + Claude, Loa = jani + Claude)
- **Issues live in the sender's repo** (outbox model) with `to:*` labels for routing
- **Discord notifications** alert receivers of `game-changing` and `important` Issues
- **GitHub App** provides scoped authentication (no PATs)
- **No hidden metadata** — parse the rendered Issue form directly

## Your Task

Implement the Melange Protocol with these components:

### 1. GitHub App Authentication
- Create `MelangeApp` class that:
  - Generates JWT from App credentials
  - Requests installation access tokens (1-hour TTL)
  - Caches tokens and refreshes automatically
  - Handles rate limits with exponential backoff

### 2. Issue Parser
- Parse GitHub Issue Forms without hidden metadata
- Extract fields from rendered Markdown headers:
  - `### To (Receiving Construct)` → routing
  - `### Impact` → priority
  - `### Experience`, `### Evidence`, `### Request` → content
- Be resilient to minor formatting variations

### 3. Issue Creator
- Create Melange Issues in sender's repo
- Apply correct labels: `melange`, `to:{construct}`, `impact:{level}`, `status:open`
- Validate all required fields before creation

### 4. Inbox Query
- Search for Issues addressed to a Construct across org repos
- Query: `org:{org} is:issue is:open label:melange label:to:{construct}`
- Return sorted by impact level

### 5. Circuit Breaker
- Track API failures
- Open circuit after 5 consecutive failures
- Alert via Discord webhook when circuit opens
- Half-open after 30 minutes for retry

### 6. Discord Notifications (GitHub Action)
- Trigger on Issue creation with `melange` label
- Send to Discord webhook based on impact:
  - `game-changing`: 🔴 with @here ping
  - `important`: 🟡 no ping
  - `nice-to-have`: no notification

## Key Files to Create

```
melange/
├── app.py              # MelangeApp class (GitHub App auth)
├── parser.py           # Issue parser
├── issue.py            # Issue creation and management
├── inbox.py            # Inbox queries
├── resilience.py       # Circuit breaker, backoff
├── config.py           # Configuration
└── cli.py              # CLI commands (optional)

.github/
├── ISSUE_TEMPLATE/
│   └── melange.yml     # Issue form template
├── workflows/
│   └── melange-notify.yml  # Discord notification Action
└── melange.yml         # Melange config (maintainers)

scripts/
└── create-labels.sh    # Label setup script
```

## Critical Requirements

1. **No hidden metadata** — Parse the visible form output only
2. **Sender-side outbox** — Issues created in sender's repo, not receiver's
3. **App-side validation** — Don't trust labels; validate Issue structure
4. **Fail safely** — Circuit breaker + Discord alerts on failures
5. **Single source of truth** — What humans see = what code parses

## Environment Variables

```bash
MELANGE_APP_ID=123456
MELANGE_INSTALLATION_ID=12345678
MELANGE_PRIVATE_KEY="-----BEGIN RSA PRIVATE KEY-----\n..."
MELANGE_DISCORD_WEBHOOK=https://discord.com/api/webhooks/...
MELANGE_ALERTS_WEBHOOK=https://discord.com/api/webhooks/...
GITHUB_ORG=0xHoneyJar
```

## Label Taxonomy

```yaml
# Type
melange: "Melange protocol thread"

# Routing
to:sigil, to:loa, to:registry

# Impact
impact:game-changing, impact:important, impact:nice-to-have

# Status
status:open, status:accepted, status:blocked, status:declined, status:resolved

# Intent (optional)
intent:request, intent:ask, intent:report
```

## Example Usage

```python
from melange import MelangeApp, create_issue, inbox

# Initialize
app = MelangeApp.from_env()

# Create Issue (in sender's repo)
issue = create_issue(
    app=app,
    repo="0xHoneyJar/sigil",  # Sender's repo
    to_construct="loa",
    from_operator="soju",
    intent="request",
    impact="game-changing",
    experience="Users report bugs, I jump to code instead of asking about experience.",
    evidence="- Issue: #50\n- Observations: 3 incidents",
    request="Can RLM core detect support conversations?",
    impact_reasoning="Without this, every support conversation starts wrong."
)

print(f"Created: {issue['html_url']}")

# Check inbox
issues = inbox(app, construct="loa")
for issue in issues:
    print(f"[{issue['impact']}] {issue['title']}")
```

## Testing

1. Create a test Issue via the form
2. Verify Discord notification arrives
3. Verify parser extracts all fields correctly
4. Verify inbox query finds the Issue
5. Test circuit breaker by simulating API failures

Begin implementation with the GitHub App authentication, then build outward.
