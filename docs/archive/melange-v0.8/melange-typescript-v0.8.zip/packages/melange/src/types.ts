/**
 * Melange Protocol Types
 */

// =============================================================================
// Core Types
// =============================================================================

export type Construct = 'sigil' | 'loa' | 'registry';

export type Intent = 'request' | 'ask' | 'report';

export type Impact = 'game-changing' | 'important' | 'nice-to-have';

export type Status = 'open' | 'accepted' | 'blocked' | 'declined' | 'resolved';

// =============================================================================
// Issue Types
// =============================================================================

export interface MelangeIssue {
  // Routing
  toConstruct: Construct;
  fromOperator: string;
  
  // Classification
  intent: Intent;
  impact: Impact;
  
  // Content
  experience: string;
  evidence: string;
  request: string;
  impactReasoning: string;
  
  // Metadata (populated from GitHub)
  number?: number;
  url?: string;
  repo?: string;
  status?: Status;
  createdAt?: string;
  updatedAt?: string;
}

export interface IssueCreateRequest {
  /** Sender's repo (e.g., "0xHoneyJar/sigil") */
  repo: string;
  
  /** Receiving construct */
  toConstruct: Construct;
  
  /** Sender's GitHub username */
  fromOperator: string;
  
  /** Message intent */
  intent: Intent;
  
  /** Impact level */
  impact: Impact;
  
  /** What's happening (concrete scenario) */
  experience: string;
  
  /** Supporting evidence (links, counts) */
  evidence: string;
  
  /** What you need from receiver */
  request: string;
  
  /** Why this impact level */
  impactReasoning: string;
  
  /** Optional custom title */
  title?: string;
}

export interface IssueSummary {
  number: number;
  title: string;
  url: string;
  repo: string;
  impact: Impact;
  status: Status;
  fromRepo: string;
  createdAt: string;
  updatedAt: string;
}

export interface IssueThread {
  issue: MelangeIssue;
  comments: IssueComment[];
}

export interface IssueComment {
  author: string;
  body: string;
  createdAt: string;
}

// =============================================================================
// GitHub API Types
// =============================================================================

export interface GitHubLabel {
  name: string;
  color?: string;
  description?: string;
}

export interface GitHubIssue {
  number: number;
  title: string;
  body: string;
  html_url: string;
  state: 'open' | 'closed';
  labels: GitHubLabel[];
  user: {
    login: string;
  };
  created_at: string;
  updated_at: string;
  repository?: {
    full_name: string;
  };
  repository_url?: string;
}

export interface GitHubComment {
  id: number;
  body: string;
  user: {
    login: string;
  };
  created_at: string;
}

export interface GitHubSearchResult {
  total_count: number;
  incomplete_results: boolean;
  items: GitHubIssue[];
}

export interface GitHubInstallationToken {
  token: string;
  expires_at: string;
  permissions: Record<string, string>;
}

// =============================================================================
// App Configuration
// =============================================================================

export interface MelangeConfig {
  appId: string;
  installationId: string;
  privateKey: string;
  org?: string;
  discordWebhook?: string;
  alertsWebhook?: string;
}

// =============================================================================
// Circuit Breaker
// =============================================================================

export type CircuitState = 'closed' | 'open' | 'half-open';

export interface CircuitBreakerConfig {
  failureThreshold?: number;
  resetTimeoutMs?: number;
}

// =============================================================================
// Discord
// =============================================================================

export interface DiscordNotification {
  title: string;
  fromConstruct: string;
  toConstruct: string;
  impact: Impact;
  url: string;
}
