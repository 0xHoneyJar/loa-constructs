/**
 * Melange Protocol - Inbox Queries
 *
 * Query for Melange Issues addressed to a Construct across all org repos.
 */

import type { MelangeApp } from './app.js';
import type {
  Construct,
  Impact,
  Status,
  IssueSummary,
  IssueThread,
  MelangeIssue,
  GitHubIssue,
  GitHubComment,
  GitHubSearchResult,
} from './types.js';
import { parseIssueFromApi, getLabelValue } from './parser.js';
import { withRetry } from './resilience.js';

/**
 * Impact priority for sorting (lower = higher priority).
 */
const IMPACT_PRIORITY: Record<string, number> = {
  'game-changing': 0,
  important: 1,
  'nice-to-have': 2,
  unknown: 3,
};

/**
 * Get all open Melange Issues addressed to a Construct.
 */
export async function inbox(
  app: MelangeApp,
  construct: Construct,
  options: {
    status?: Status;
    impact?: Impact;
  } = {}
): Promise<IssueSummary[]> {
  const org = app.getOrg();

  // Build search query
  const queryParts = [
    `org:${org}`,
    'is:issue',
    'is:open',
    'label:melange',
    `label:to:${construct}`,
  ];

  if (options.status) {
    queryParts.push(`label:status:${options.status}`);
  }

  if (options.impact) {
    queryParts.push(`label:impact:${options.impact}`);
  }

  const query = queryParts.join(' ');

  // Search
  const results = await withRetry(async () => {
    return app.get<GitHubSearchResult>('/search/issues', {
      q: query,
      sort: 'created',
      order: 'desc',
      per_page: '100',
    });
  });

  // Parse results
  const issues: IssueSummary[] = results.items.map((item) => {
    const labels = item.labels;
    const impactValue = getLabelValue(labels, 'impact:') || 'unknown';
    const statusValue = getLabelValue(labels, 'status:') || 'open';

    // Determine sender from repo URL
    const repoUrl = item.repository_url || '';
    const repoName = repoUrl.split('/').pop() || 'unknown';

    return {
      number: item.number,
      title: item.title,
      url: item.html_url,
      repo: `${org}/${repoName}`,
      impact: impactValue as Impact,
      status: statusValue as Status,
      fromRepo: repoName,
      createdAt: item.created_at,
      updatedAt: item.updated_at,
    };
  });

  // Sort by impact priority
  issues.sort(
    (a, b) =>
      (IMPACT_PRIORITY[a.impact] ?? 3) - (IMPACT_PRIORITY[b.impact] ?? 3)
  );

  return issues;
}

/**
 * Get and parse a specific Melange Issue.
 */
export async function getIssue(
  app: MelangeApp,
  repo: string,
  issueNumber: number
): Promise<MelangeIssue> {
  const [owner, repoName] = repo.split('/');

  const issueData = await withRetry(async () => {
    return app.get<GitHubIssue>(
      `/repos/${owner}/${repoName}/issues/${issueNumber}`
    );
  });

  // Add repository info for parsing
  issueData.repository = { full_name: repo };

  return parseIssueFromApi(issueData);
}

/**
 * Get a Melange Issue with all its comments (full thread).
 */
export async function getThread(
  app: MelangeApp,
  repo: string,
  issueNumber: number
): Promise<IssueThread> {
  const [owner, repoName] = repo.split('/');

  // Get Issue
  const issue = await getIssue(app, repo, issueNumber);

  // Get comments
  const comments = await withRetry(async () => {
    return app.get<GitHubComment[]>(
      `/repos/${owner}/${repoName}/issues/${issueNumber}/comments`,
      { per_page: '100' }
    );
  });

  return {
    issue,
    comments: comments.map((c) => ({
      author: c.user.login,
      body: c.body,
      createdAt: c.created_at,
    })),
  };
}

/**
 * Search for Melange Issues by query.
 */
export async function searchIssues(
  app: MelangeApp,
  searchQuery: string,
  options: {
    construct?: Construct;
    impact?: Impact;
    status?: Status;
    limit?: number;
  } = {}
): Promise<IssueSummary[]> {
  const org = app.getOrg();

  // Build search query
  const queryParts = [
    `org:${org}`,
    'is:issue',
    'label:melange',
    searchQuery,
  ];

  if (options.construct) {
    queryParts.push(`label:to:${options.construct}`);
  }

  if (options.impact) {
    queryParts.push(`label:impact:${options.impact}`);
  }

  if (options.status) {
    queryParts.push(`label:status:${options.status}`);
  }

  const query = queryParts.join(' ');
  const limit = options.limit ?? 50;

  const results = await withRetry(async () => {
    return app.get<GitHubSearchResult>('/search/issues', {
      q: query,
      sort: 'updated',
      order: 'desc',
      per_page: String(Math.min(limit, 100)),
    });
  });

  return results.items.map((item) => {
    const labels = item.labels;
    const impactValue = getLabelValue(labels, 'impact:') || 'unknown';
    const statusValue = getLabelValue(labels, 'status:') || 'open';
    const repoUrl = item.repository_url || '';
    const repoName = repoUrl.split('/').pop() || 'unknown';

    return {
      number: item.number,
      title: item.title,
      url: item.html_url,
      repo: `${org}/${repoName}`,
      impact: impactValue as Impact,
      status: statusValue as Status,
      fromRepo: repoName,
      createdAt: item.created_at,
      updatedAt: item.updated_at,
    };
  });
}

/**
 * Get all open Melange Issues created by a Construct (outbox).
 */
export async function outbox(
  app: MelangeApp,
  construct: Construct,
  options: {
    status?: Status;
  } = {}
): Promise<IssueSummary[]> {
  const org = app.getOrg();

  // Build search query
  const queryParts = [
    `repo:${org}/${construct}`,
    'is:issue',
    'is:open',
    'label:melange',
  ];

  if (options.status) {
    queryParts.push(`label:status:${options.status}`);
  }

  const query = queryParts.join(' ');

  const results = await withRetry(async () => {
    return app.get<GitHubSearchResult>('/search/issues', {
      q: query,
      sort: 'created',
      order: 'desc',
      per_page: '100',
    });
  });

  return results.items.map((item) => {
    const labels = item.labels;
    const impactValue = getLabelValue(labels, 'impact:') || 'unknown';
    const statusValue = getLabelValue(labels, 'status:') || 'open';
    const toConstruct = getLabelValue(labels, 'to:') || 'unknown';

    return {
      number: item.number,
      title: item.title,
      url: item.html_url,
      repo: `${org}/${construct}`,
      impact: impactValue as Impact,
      status: statusValue as Status,
      fromRepo: construct,
      createdAt: item.created_at,
      updatedAt: item.updated_at,
    };
  });
}
