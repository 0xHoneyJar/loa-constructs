/**
 * Melange Protocol v0.8
 *
 * Sender-side outbox communication for Constructs using GitHub Issues.
 *
 * @packageDocumentation
 */

// App
export { MelangeApp } from './app.js';

// Types
export type {
  Construct,
  Intent,
  Impact,
  Status,
  MelangeIssue,
  IssueCreateRequest,
  IssueSummary,
  IssueThread,
  IssueComment,
  MelangeConfig,
  CircuitState,
  CircuitBreakerConfig,
  DiscordNotification,
  GitHubIssue,
  GitHubLabel,
  GitHubComment,
  GitHubSearchResult,
} from './types.js';

// Parser
export {
  parseMelangeIssue,
  parseIssueFromApi,
  validateMelangeIssue,
  getLabelValue,
} from './parser.js';

// Issue Management
export {
  createIssue,
  updateStatus,
  addComment,
  closeIssue,
  acceptIssue,
  declineIssue,
  blockIssue,
  resolveIssue,
} from './issue.js';

// Inbox
export {
  inbox,
  outbox,
  getIssue,
  getThread,
  searchIssues,
} from './inbox.js';

// Resilience
export {
  withRetry,
  CircuitBreaker,
  getCircuitBreaker,
  withCircuitBreaker,
  sendDiscordAlert,
  sendMelangeNotification,
} from './resilience.js';
export type { RetryOptions } from './resilience.js';
