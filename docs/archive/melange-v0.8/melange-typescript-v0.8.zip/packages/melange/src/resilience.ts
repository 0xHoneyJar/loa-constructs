/**
 * Melange Protocol - Resilience Patterns
 *
 * Exponential backoff and circuit breaker for API reliability.
 */

import type { CircuitState, CircuitBreakerConfig, DiscordNotification, Impact } from './types.js';

// =============================================================================
// Exponential Backoff
// =============================================================================

export interface RetryOptions {
  maxRetries?: number;
  baseDelayMs?: number;
  maxDelayMs?: number;
}

/**
 * Execute function with exponential backoff on failure.
 */
export async function withRetry<T>(
  fn: () => Promise<T>,
  options: RetryOptions = {}
): Promise<T> {
  const { maxRetries = 5, baseDelayMs = 1000, maxDelayMs = 60000 } = options;

  let lastError: Error | undefined;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));

      if (attempt === maxRetries - 1) {
        throw lastError;
      }

      // Calculate delay with exponential backoff + jitter
      const delay = Math.min(baseDelayMs * Math.pow(2, attempt), maxDelayMs);
      const jitter = Math.random() * delay * 0.1;
      const totalDelay = delay + jitter;

      console.warn(
        `Attempt ${attempt + 1} failed: ${lastError.message}. Retrying in ${totalDelay.toFixed(0)}ms`
      );

      await sleep(totalDelay);
    }
  }

  throw lastError;
}

/**
 * Sleep for specified milliseconds.
 */
function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// =============================================================================
// Circuit Breaker
// =============================================================================

/**
 * Circuit breaker for API calls.
 *
 * States:
 * - CLOSED: Normal operation, requests pass through
 * - OPEN: Failures exceeded threshold, requests blocked
 * - HALF_OPEN: Testing if service recovered
 */
export class CircuitBreaker {
  private failureThreshold: number;
  private resetTimeoutMs: number;

  private failures = 0;
  private lastFailure: number | null = null;
  private state: CircuitState = 'closed';
  private alertSent = false;

  constructor(config: CircuitBreakerConfig = {}) {
    this.failureThreshold = config.failureThreshold ?? 5;
    this.resetTimeoutMs = config.resetTimeoutMs ?? 30 * 60 * 1000; // 30 minutes
  }

  /**
   * Check if request should proceed.
   */
  canProceed(): boolean {
    if (this.state === 'closed') {
      return true;
    }

    if (this.state === 'open') {
      // Check if timeout has passed
      if (
        this.lastFailure &&
        Date.now() - this.lastFailure > this.resetTimeoutMs
      ) {
        this.state = 'half-open';
        return true;
      }
      return false;
    }

    // half-open: allow one test request
    return true;
  }

  /**
   * Record successful request.
   */
  recordSuccess(): void {
    this.failures = 0;
    this.state = 'closed';
    this.alertSent = false;
  }

  /**
   * Record failed request.
   */
  recordFailure(): void {
    this.failures++;
    this.lastFailure = Date.now();

    if (this.failures >= this.failureThreshold) {
      this.state = 'open';
      if (!this.alertSent) {
        this.sendAlert();
        this.alertSent = true;
      }
    }
  }

  /**
   * Send alert when circuit opens.
   */
  private async sendAlert(): Promise<void> {
    const webhookUrl = process.env.MELANGE_ALERTS_WEBHOOK;
    if (!webhookUrl) {
      console.error(
        'WARNING: Circuit breaker opened but no alert webhook configured'
      );
      return;
    }

    const message =
      `⚠️ **Melange Circuit Breaker OPEN**\n\n` +
      `GitHub API failures exceeded threshold (${this.failureThreshold}).\n` +
      `Circuit will attempt recovery in ${this.resetTimeoutMs / 60000} minutes.\n` +
      `Manual intervention may be required.`;

    try {
      await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: message }),
      });
    } catch (error) {
      console.error('Failed to send circuit breaker alert:', error);
    }
  }

  /**
   * Get current state.
   */
  getState(): CircuitState {
    return this.state;
  }

  /**
   * Get current failure count.
   */
  getFailureCount(): number {
    return this.failures;
  }

  /**
   * Reset the circuit breaker.
   */
  reset(): void {
    this.failures = 0;
    this.lastFailure = null;
    this.state = 'closed';
    this.alertSent = false;
  }
}

// Global circuit breaker instance
let globalCircuitBreaker: CircuitBreaker | null = null;

/**
 * Get the global circuit breaker instance.
 */
export function getCircuitBreaker(): CircuitBreaker {
  if (!globalCircuitBreaker) {
    globalCircuitBreaker = new CircuitBreaker();
  }
  return globalCircuitBreaker;
}

/**
 * Execute function with circuit breaker protection.
 */
export async function withCircuitBreaker<T>(fn: () => Promise<T>): Promise<T> {
  const breaker = getCircuitBreaker();

  if (!breaker.canProceed()) {
    throw new Error(
      `Circuit breaker is ${breaker.getState()}. ` +
        `Failures: ${breaker.getFailureCount()}. ` +
        `Manual intervention required.`
    );
  }

  try {
    const result = await fn();
    breaker.recordSuccess();
    return result;
  } catch (error) {
    breaker.recordFailure();
    throw error;
  }
}

// =============================================================================
// Discord Notifications
// =============================================================================

/**
 * Send alert to Discord.
 */
export async function sendDiscordAlert(
  message: string,
  webhookUrl?: string
): Promise<boolean> {
  const url = webhookUrl ?? process.env.MELANGE_ALERTS_WEBHOOK;
  if (!url) {
    console.log(`ALERT (no webhook): ${message}`);
    return false;
  }

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: message }),
    });
    return response.status === 204 || response.ok;
  } catch (error) {
    console.error('Failed to send Discord alert:', error);
    return false;
  }
}

/**
 * Send Melange Issue notification to Discord.
 */
export async function sendMelangeNotification(
  notification: DiscordNotification,
  webhookUrl?: string
): Promise<boolean> {
  const webhook = webhookUrl ?? process.env.MELANGE_DISCORD_WEBHOOK;
  if (!webhook) {
    return false;
  }

  const { title, fromConstruct, toConstruct, impact, url } = notification;

  // Format based on impact
  let emoji: string;
  let ping: string;

  switch (impact) {
    case 'game-changing':
      emoji = '🔴';
      ping = '\n\n@here';
      break;
    case 'important':
      emoji = '🟡';
      ping = '';
      break;
    default:
      // nice-to-have: no notification
      return true;
  }

  const message = `${emoji} **[${impact}] ${fromConstruct} → ${toConstruct}**\n\n${title}\n\n${url}${ping}`;

  try {
    const response = await fetch(webhook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: message }),
    });
    return response.status === 204 || response.ok;
  } catch (error) {
    console.error('Failed to send Melange notification:', error);
    return false;
  }
}
