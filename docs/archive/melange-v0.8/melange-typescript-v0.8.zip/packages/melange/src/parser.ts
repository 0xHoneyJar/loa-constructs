/**
 * Melange Protocol - Issue Parser
 *
 * Parses GitHub Issues created via the Melange YAML form.
 * No hidden metadata - parses the visible rendered form directly.
 */

import type {
  MelangeIssue,
  GitHubIssue,
  GitHubLabel,
  Construct,
  Intent,
  Impact,
  Status,
} from './types.js';

/**
 * Extract a field value from the rendered Issue form.
 *
 * GitHub renders YAML forms as:
 * ### Field Name
 *
 * <value>
 *
 * ### Next Field
 */
function extractField(body: string, fieldName: string): string {
  // Escape special regex characters
  const escapedName = fieldName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match: ### Field Name\n\n<content>\n\n### (or end)
  const pattern = new RegExp(
    `###\\s*${escapedName}\\s*\\n\\n(.*?)(?=\\n\\n###|\\n\\n---|$)`,
    'is'
  );
  
  const match = body.match(pattern);
  return match ? match[1].trim() : '';
}

/**
 * Extract value before delimiter.
 *
 * Example: "game-changing — Blocks core workflow" → "game-changing"
 */
function extractValueBeforeDelimiter(value: string, delimiter = ' — '): string {
  if (value.includes(delimiter)) {
    return value.split(delimiter)[0].trim();
  }
  return value.trim();
}

/**
 * Extract label value by prefix.
 *
 * Example: labels=[{name: "to:loa"}], prefix="to:" → "loa"
 */
export function getLabelValue(
  labels: GitHubLabel[],
  prefix: string
): string | undefined {
  const label = labels.find((l) => l.name.startsWith(prefix));
  return label ? label.name.slice(prefix.length) : undefined;
}

/**
 * Parse a Melange Issue from its rendered body.
 */
export function parseMelangeIssue(body: string): MelangeIssue {
  // Extract all fields
  const toConstruct = extractField(body, 'To (Receiving Construct)');
  const fromOperator = extractField(body, 'From (Your GitHub username)');
  const intentRaw = extractField(body, 'Intent');
  const impactRaw = extractField(body, 'Impact');
  const experience = extractField(body, 'Experience');
  const evidence = extractField(body, 'Evidence');
  const request = extractField(body, 'Request');
  const impactReasoning = extractField(body, 'Impact Reasoning');

  // Clean up dropdown values
  const intent = extractValueBeforeDelimiter(intentRaw);
  const impact = extractValueBeforeDelimiter(impactRaw);

  // Validate required fields
  if (!toConstruct) {
    throw new Error('Missing required field: To (Receiving Construct)');
  }
  if (!impact) {
    throw new Error('Missing required field: Impact');
  }
  if (!experience) {
    throw new Error('Missing required field: Experience');
  }

  return {
    toConstruct: toConstruct.toLowerCase() as Construct,
    fromOperator,
    intent: (intent.toLowerCase() || 'request') as Intent,
    impact: impact.toLowerCase() as Impact,
    experience,
    evidence,
    request,
    impactReasoning,
  };
}

/**
 * Parse a Melange Issue from GitHub API response.
 */
export function parseIssueFromApi(issueData: GitHubIssue): MelangeIssue {
  const parsed = parseMelangeIssue(issueData.body);

  // Add metadata
  parsed.number = issueData.number;
  parsed.url = issueData.html_url;
  parsed.repo = issueData.repository?.full_name;
  parsed.createdAt = issueData.created_at;
  parsed.updatedAt = issueData.updated_at;

  // Extract status from labels
  const statusValue = getLabelValue(issueData.labels, 'status:');
  parsed.status = (statusValue as Status) || 'open';

  return parsed;
}

/**
 * Validate that an Issue is a legitimate Melange Issue.
 */
export function validateMelangeIssue(issueData: GitHubIssue): boolean {
  const labels = issueData.labels.map((l) => l.name);

  // Must have melange label
  if (!labels.includes('melange')) {
    return false;
  }

  // Must have exactly one to:* label
  const toLabels = labels.filter((l) => l.startsWith('to:'));
  if (toLabels.length !== 1) {
    return false;
  }

  // Must have exactly one impact:* label
  const impactLabels = labels.filter((l) => l.startsWith('impact:'));
  if (impactLabels.length !== 1) {
    return false;
  }

  // Must be parseable
  try {
    parseMelangeIssue(issueData.body);
  } catch {
    return false;
  }

  return true;
}
