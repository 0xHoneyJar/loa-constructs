/**
 * Melange Protocol - Issue Management
 *
 * Create and manage Melange Issues in sender's repo (outbox model).
 */

import type { MelangeApp } from './app.js';
import type {
  IssueCreateRequest,
  GitHubIssue,
  GitHubLabel,
  Status,
} from './types.js';
import { withRetry } from './resilience.js';

/**
 * Intent descriptions for form output.
 */
const INTENT_DESCRIPTIONS: Record<string, string> = {
  request: 'Need capability or change',
  ask: 'Need information',
  report: 'Sharing experience',
};

/**
 * Impact descriptions for form output.
 */
const IMPACT_DESCRIPTIONS: Record<string, string> = {
  'game-changing': 'Blocks core workflow',
  important: 'Significant friction',
  'nice-to-have': 'Improvement',
};

/**
 * Format Issue body to match YAML form output.
 */
function formatIssueBody(req: IssueCreateRequest): string {
  const intentDesc = INTENT_DESCRIPTIONS[req.intent] || req.intent;
  const impactDesc = IMPACT_DESCRIPTIONS[req.impact] || req.impact;

  return `### To (Receiving Construct)

${req.toConstruct}

### From (Your GitHub username)

${req.fromOperator}

### Intent

${req.intent} — ${intentDesc}

### Impact

${req.impact} — ${impactDesc}

### Experience

${req.experience}

### Evidence

${req.evidence}

### Request

${req.request}

### Impact Reasoning

${req.impactReasoning}
`;
}

/**
 * Create a Melange Issue in the sender's repo.
 */
export async function createIssue(
  app: MelangeApp,
  req: IssueCreateRequest
): Promise<GitHubIssue> {
  // Generate title
  let title = req.title || `${req.request.slice(0, 60)}...`;
  if (!title.startsWith('[Melange]')) {
    title = `[Melange] ${title}`;
  }

  // Format body
  const body = formatIssueBody(req);

  // Build labels
  const labels = [
    'melange',
    `to:${req.toConstruct}`,
    `impact:${req.impact}`,
    `intent:${req.intent}`,
    'status:open',
  ];

  // Parse repo
  const [owner, repo] = req.repo.split('/');

  // Create Issue
  return withRetry(async () => {
    return app.post<GitHubIssue>(`/repos/${owner}/${repo}/issues`, {
      title,
      body,
      labels,
    });
  });
}

/**
 * Update the status label on a Melange Issue.
 */
export async function updateStatus(
  app: MelangeApp,
  repo: string,
  issueNumber: number,
  status: Status
): Promise<GitHubIssue> {
  const [owner, repoName] = repo.split('/');

  // Get current labels
  const issue = await app.get<GitHubIssue>(
    `/repos/${owner}/${repoName}/issues/${issueNumber}`
  );

  // Remove old status labels, add new one
  const currentLabels = issue.labels.map((l: GitHubLabel) => l.name);
  const newLabels = currentLabels.filter((l: string) => !l.startsWith('status:'));
  newLabels.push(`status:${status}`);

  // Update
  return withRetry(async () => {
    return app.patch<GitHubIssue>(
      `/repos/${owner}/${repoName}/issues/${issueNumber}`,
      { labels: newLabels }
    );
  });
}

/**
 * Add a comment to a Melange Issue.
 */
export async function addComment(
  app: MelangeApp,
  repo: string,
  issueNumber: number,
  body: string
): Promise<{ id: number; body: string }> {
  const [owner, repoName] = repo.split('/');

  return withRetry(async () => {
    return app.post<{ id: number; body: string }>(
      `/repos/${owner}/${repoName}/issues/${issueNumber}/comments`,
      { body }
    );
  });
}

/**
 * Close a Melange Issue with optional resolution comment.
 */
export async function closeIssue(
  app: MelangeApp,
  repo: string,
  issueNumber: number,
  comment?: string
): Promise<GitHubIssue> {
  const [owner, repoName] = repo.split('/');

  // Add comment if provided
  if (comment) {
    await addComment(app, repo, issueNumber, comment);
  }

  // Update status label
  await updateStatus(app, repo, issueNumber, 'resolved');

  // Close issue
  return withRetry(async () => {
    return app.patch<GitHubIssue>(
      `/repos/${owner}/${repoName}/issues/${issueNumber}`,
      { state: 'closed' }
    );
  });
}

/**
 * Accept a Melange Issue (receiver acknowledges and will work on it).
 */
export async function acceptIssue(
  app: MelangeApp,
  repo: string,
  issueNumber: number,
  message = 'Accepted.'
): Promise<GitHubIssue> {
  await addComment(app, repo, issueNumber, `**${message}**`);
  return updateStatus(app, repo, issueNumber, 'accepted');
}

/**
 * Decline a Melange Issue with reason.
 */
export async function declineIssue(
  app: MelangeApp,
  repo: string,
  issueNumber: number,
  reason: string
): Promise<GitHubIssue> {
  const comment = `**Declined.**\n\n${reason}`;
  return closeIssue(app, repo, issueNumber, comment);
}

/**
 * Mark a Melange Issue as blocked.
 */
export async function blockIssue(
  app: MelangeApp,
  repo: string,
  issueNumber: number,
  reason: string
): Promise<GitHubIssue> {
  await addComment(app, repo, issueNumber, `**Blocked:** ${reason}`);
  return updateStatus(app, repo, issueNumber, 'blocked');
}

/**
 * Resolve a Melange Issue with artifact reference.
 */
export async function resolveIssue(
  app: MelangeApp,
  repo: string,
  issueNumber: number,
  artifactRef: string
): Promise<GitHubIssue> {
  return closeIssue(app, repo, issueNumber, `Resolved via ${artifactRef}`);
}
