/**
 * Melange Protocol - GitHub App Authentication
 *
 * Handles JWT generation and installation token management.
 * Tokens are cached and auto-refreshed.
 */

import jwt from 'jsonwebtoken';
import type { MelangeConfig, GitHubInstallationToken } from './types.js';

const GITHUB_API = 'https://api.github.com';

export class MelangeApp {
  private appId: string;
  private installationId: string;
  private privateKey: string;
  private org: string;
  
  private token: string | null = null;
  private tokenExpires: number = 0;

  constructor(config: MelangeConfig) {
    this.appId = config.appId;
    this.installationId = config.installationId;
    this.privateKey = config.privateKey;
    this.org = config.org ?? '0xHoneyJar';
  }

  /**
   * Create MelangeApp from environment variables.
   */
  static fromEnv(): MelangeApp {
    const appId = process.env.MELANGE_APP_ID;
    const installationId = process.env.MELANGE_INSTALLATION_ID;
    const privateKey = process.env.MELANGE_PRIVATE_KEY;
    const org = process.env.GITHUB_ORG;

    if (!appId || !installationId || !privateKey) {
      throw new Error(
        'Missing required environment variables: MELANGE_APP_ID, MELANGE_INSTALLATION_ID, MELANGE_PRIVATE_KEY'
      );
    }

    return new MelangeApp({
      appId,
      installationId,
      privateKey,
      org,
    });
  }

  /**
   * Generate JWT for GitHub App authentication.
   */
  private generateJwt(): string {
    const now = Math.floor(Date.now() / 1000);
    
    const payload = {
      iat: now - 60,      // Issued 60s ago (clock skew tolerance)
      exp: now + 600,     // Expires in 10 minutes
      iss: this.appId,
    };

    return jwt.sign(payload, this.privateKey, { algorithm: 'RS256' });
  }

  /**
   * Get installation access token.
   * Tokens are cached and auto-refreshed when <5 minutes remain.
   */
  async getToken(): Promise<string> {
    // Return cached token if still valid (with 5 min buffer)
    const now = Date.now();
    if (this.token && now < this.tokenExpires - 300_000) {
      return this.token;
    }

    // Request new token
    const jwtToken = this.generateJwt();
    
    const response = await fetch(
      `${GITHUB_API}/app/installations/${this.installationId}/access_tokens`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${jwtToken}`,
          Accept: 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28',
        },
      }
    );

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Failed to get installation token: ${response.status} ${error}`);
    }

    const data = (await response.json()) as GitHubInstallationToken;
    
    this.token = data.token;
    // Tokens are typically valid for 1 hour
    this.tokenExpires = Date.now() + 3600_000;

    return this.token;
  }

  /**
   * Make authenticated request to GitHub API.
   */
  async request<T = unknown>(
    method: string,
    endpoint: string,
    options: {
      body?: unknown;
      params?: Record<string, string>;
    } = {}
  ): Promise<T> {
    const token = await this.getToken();
    
    let url = `${GITHUB_API}${endpoint}`;
    
    if (options.params) {
      const searchParams = new URLSearchParams(options.params);
      url += `?${searchParams.toString()}`;
    }

    const response = await fetch(url, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      },
      body: options.body ? JSON.stringify(options.body) : undefined,
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`GitHub API error: ${response.status} ${error}`);
    }

    return response.json() as Promise<T>;
  }

  /**
   * GET request to GitHub API.
   */
  async get<T = unknown>(
    endpoint: string,
    params?: Record<string, string>
  ): Promise<T> {
    return this.request<T>('GET', endpoint, { params });
  }

  /**
   * POST request to GitHub API.
   */
  async post<T = unknown>(endpoint: string, body?: unknown): Promise<T> {
    return this.request<T>('POST', endpoint, { body });
  }

  /**
   * PATCH request to GitHub API.
   */
  async patch<T = unknown>(endpoint: string, body?: unknown): Promise<T> {
    return this.request<T>('PATCH', endpoint, { body });
  }

  /**
   * Get the configured organization.
   */
  getOrg(): string {
    return this.org;
  }
}
