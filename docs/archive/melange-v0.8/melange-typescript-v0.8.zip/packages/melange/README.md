# @loa-constructs/melange

Sender-side outbox communication protocol for Constructs using GitHub Issues.

## Installation

```bash
pnpm add @loa-constructs/melange
```

## Quick Start

### Environment Variables

```bash
MELANGE_APP_ID=123456
MELANGE_INSTALLATION_ID=12345678
MELANGE_PRIVATE_KEY="-----BEGIN RSA PRIVATE KEY-----\n..."
MELANGE_DISCORD_WEBHOOK=https://discord.com/api/webhooks/...
MELANGE_ALERTS_WEBHOOK=https://discord.com/api/webhooks/...  # Optional
GITHUB_ORG=0xHoneyJar
```

### Create a Melange Issue

```typescript
import { MelangeApp, createIssue } from '@loa-constructs/melange';

const app = MelangeApp.fromEnv();

const issue = await createIssue(app, {
  repo: '0xHoneyJar/sigil',      // Sender's repo
  toConstruct: 'loa',            // Receiver
  fromOperator: 'soju',
  intent: 'request',
  impact: 'game-changing',
  experience: 'Users report bugs, I jump to code instead of asking about experience.',
  evidence: '- Issue: #50\n- Observations: 3 incidents',
  request: 'Can RLM core detect support conversations?',
  impactReasoning: 'Without this, every support conversation starts wrong.',
});

console.log(`Created: ${issue.html_url}`);
```

### Check Inbox

```typescript
import { MelangeApp, inbox } from '@loa-constructs/melange';

const app = MelangeApp.fromEnv();

// Get all Issues addressed to Loa
const issues = await inbox(app, 'loa');

for (const issue of issues) {
  console.log(`[${issue.impact}] ${issue.title} (${issue.repo}#${issue.number})`);
}
```

### Accept an Issue

```typescript
import { MelangeApp, acceptIssue } from '@loa-constructs/melange';

const app = MelangeApp.fromEnv();

await acceptIssue(app, '0xHoneyJar/sigil', 10, 'Accepted. Building this in Loa.');
```

### Resolve an Issue

```typescript
import { MelangeApp, resolveIssue } from '@loa-constructs/melange';

const app = MelangeApp.fromEnv();

await resolveIssue(app, '0xHoneyJar/sigil', 10, '0xHoneyJar/loa#49');
```

## API Reference

### App

- `MelangeApp.fromEnv()` - Create app from environment variables
- `new MelangeApp(config)` - Create app from config object

### Issue Management

- `createIssue(app, request)` - Create a new Melange Issue
- `acceptIssue(app, repo, number, message?)` - Accept an Issue
- `declineIssue(app, repo, number, reason)` - Decline an Issue
- `blockIssue(app, repo, number, reason)` - Mark Issue as blocked
- `resolveIssue(app, repo, number, artifactRef)` - Resolve with artifact
- `closeIssue(app, repo, number, comment?)` - Close an Issue
- `addComment(app, repo, number, body)` - Add comment
- `updateStatus(app, repo, number, status)` - Update status label

### Inbox

- `inbox(app, construct, options?)` - Get Issues addressed to Construct
- `outbox(app, construct, options?)` - Get Issues created by Construct
- `getIssue(app, repo, number)` - Get single Issue
- `getThread(app, repo, number)` - Get Issue with all comments
- `searchIssues(app, query, options?)` - Search Issues

### Parser

- `parseMelangeIssue(body)` - Parse Issue body
- `parseIssueFromApi(issueData)` - Parse from GitHub API response
- `validateMelangeIssue(issueData)` - Validate Issue structure

### Resilience

- `withRetry(fn, options?)` - Execute with exponential backoff
- `CircuitBreaker` - Circuit breaker class
- `withCircuitBreaker(fn)` - Execute with circuit breaker
- `sendDiscordAlert(message, webhookUrl?)` - Send Discord alert
- `sendMelangeNotification(notification, webhookUrl?)` - Send Issue notification

## Types

```typescript
type Construct = 'sigil' | 'loa' | 'registry';
type Intent = 'request' | 'ask' | 'report';
type Impact = 'game-changing' | 'important' | 'nice-to-have';
type Status = 'open' | 'accepted' | 'blocked' | 'declined' | 'resolved';
```

## Setup

### 1. Create GitHub App

1. Go to GitHub → Settings → Developer Settings → GitHub Apps
2. Create new App named "Melange"
3. Set permissions:
   - Issues: Read & Write
   - Pull Requests: Read & Write
   - Metadata: Read
   - Contents: Read
4. Install on your repos
5. Generate and download private key

### 2. Setup Labels

```bash
./scripts/create-labels.sh 0xHoneyJar/sigil
./scripts/create-labels.sh 0xHoneyJar/loa
./scripts/create-labels.sh 0xHoneyJar/registry
```

### 3. Copy GitHub Files

Copy to each repo:
- `.github/ISSUE_TEMPLATE/melange.yml`
- `.github/workflows/melange-notify.yml`

Add secret `MELANGE_DISCORD_WEBHOOK` to each repo.

## Architecture

See the [Architecture document](../../ARCHITECTURE.md) for full system design.

Key principles:
1. **Sender-side outbox** — Issues live in sender's repo
2. **No hidden metadata** — Parse visible form output
3. **Discord for critical** — Real-time notifications
4. **GitHub App** — Scoped permissions, no PATs
5. **Link, don't transfer** — Single Issue history

## License

AGPL-3.0
